# Baseline

# 1. cd Baseline

# 2. chmod +x run_baseline.sh

# 3. ./run_baseline.sh

# Multitasking

# 4. cd Multitasking

# 5. chmod +x run_multitasking.sh

# 6. ./run_baseline.sh

# Multithreading

# 7. cd Multithreading

# 8. chmod +x run_multithreading.sh

# 9. ./run_baseline.sh
